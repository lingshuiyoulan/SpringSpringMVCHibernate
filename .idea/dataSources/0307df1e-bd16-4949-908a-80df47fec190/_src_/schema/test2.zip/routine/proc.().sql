CREATE PROCEDURE `proc`()
  begin
 select 3+5 into res;
end